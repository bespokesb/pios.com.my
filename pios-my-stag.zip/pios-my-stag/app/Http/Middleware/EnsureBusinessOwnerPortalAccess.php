<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureBusinessOwnerPortalAccess
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if (! $user || (! $user->isBusinessOwner() && ! $user->isAdmin())) {
            abort(403, 'Unauthorized access to Business Owner portal.');
        }

        return $next($request);
    }
}
